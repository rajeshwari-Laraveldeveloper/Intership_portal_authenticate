<?php
include('../config.php');

if($_SERVER['REQUEST_METHOD']==='POST'  && $_POST['action']='add')
{
    $Firstname=$_POST['firstname'];
    $Lastname=$_POST['lastname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $id= $_POST['userid'];
    

    $sql=" INSERT INTO  registercandidate (Firstname,Lastname,Email,Password) 
    VALUES (:firstname,:lastname,:email,:password);";
    $stmt=$conn->prepare($sql);
    $parameter=array(
        ':firstname' => $Firstname,
        ':lastname' => $Lastname,
        ':email' => $email,
        ':password' => $password
    );
    $stmt->execute($parameter);
    if($id==''){
        echo json_encode([
            'status' => 'success',
            'message' => 'Hello, ' . $Firstname . $Lastname . '! Your email ' . $Email . ' has been successfully Registered <br> Please! go to login in Log-In page...'
            ]);
        }   
        else{
             
  echo json_encode([
    'status' => 'unsuccess',
    'message' => 'Sorry, ' . $Firstname . $Lastname . '! Your email (' . $Email . ') has been Registered.'
    ]);
        }  
   
   
    // if(!empty($result)){
    //     $_SESSION['Email']=$result['Email'];
    //     $_SESSION['FirstName']=$result['FirstName'];
    //     $_SESSION['LastName']=$result['LastName'];

    // }
}


?>