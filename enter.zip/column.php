<?php include("header.php") ?>

<div class="move ">
    
       <div class="box text-black btn-get-started"><a href="candidatelogin.php">Login-In as a Candidate</a> </div>
       <div class="box text-black btn-get-started"><a href="employerlogin.php">Login -In as a Employer</a> </div>

</div>



<?php include("footer.php") ?>